# Automated Diagnostic System - Design Guidelines

## Design Approach

**Selected Approach**: Design System-Based (Enterprise Medical Application)

**Primary Inspiration**: Material Design + Healthcare Dashboard Patterns (Epic, Cerner UI principles)

**Rationale**: This is a utility-focused, information-dense medical application where trust, professionalism, clarity, and efficiency are paramount. The design must prioritize data hierarchy, accessibility, and consistent patterns over visual flair.

---

## Core Design Elements

### A. Typography

**Font Families** (via Google Fonts CDN):
- Primary: Inter (400, 500, 600, 700) - for UI, forms, body text
- Monospace: JetBrains Mono (400, 500) - for lab values, numerical data, patient IDs

**Type Scale**:
- Display: text-4xl (36px) / font-bold - Dashboard headers
- H1: text-3xl (30px) / font-semibold - Section titles
- H2: text-2xl (24px) / font-semibold - Card headers
- H3: text-xl (20px) / font-medium - Subsections
- Body Large: text-base (16px) / font-normal - Primary content
- Body: text-sm (14px) / font-normal - Secondary content, labels
- Caption: text-xs (12px) / font-medium - Metadata, timestamps
- Data Values: text-lg (18px) / font-mono / font-medium - Lab results, metrics

---

### B. Layout System

**Spacing Primitives** (Tailwind units):
- Core spacing: **2, 4, 6, 8, 12, 16** (as in p-2, m-4, gap-6, py-8, space-y-12, mt-16)
- These units create consistent rhythm throughout the application

**Grid System**:
- Dashboard: 12-column grid (grid-cols-12) for complex layouts
- Forms: Single column on mobile, 2-column (grid-cols-2) on desktop for side-by-side fields
- Results Cards: 1 column mobile, 2-3 columns tablet/desktop (md:grid-cols-2 lg:grid-cols-3)

**Container Widths**:
- Main content: max-w-7xl (1280px)
- Forms: max-w-3xl (768px)
- Dashboard panels: Full width with internal spacing

**Vertical Rhythm**:
- Section padding: py-8 (mobile), py-12 (desktop)
- Card padding: p-6
- Form groups: space-y-6
- List items: space-y-4

---

### C. Component Library

#### 1. Navigation & Header
- **Top Navigation Bar**: Fixed header with app logo/title, user profile, notification icon
- Height: h-16
- Layout: Horizontal flex with space-between
- Search bar integrated (for patient lookup)
- Breadcrumb navigation below header for deep pages

#### 2. Dashboard Layout
- **Sidebar Navigation** (left, sticky):
  - Width: w-64
  - Icons from Heroicons (outline style)
  - Navigation items: Dashboard, New Analysis, Patient History, Reports, Settings
  - Vertical list with py-3 px-4 per item
  
- **Main Content Area**:
  - Grid of stat cards (grid-cols-1 md:grid-cols-2 lg:grid-cols-4)
  - Each card: rounded-lg border with p-6
  - Recent analyses table below stats

#### 3. Patient Data Input Form
- **Multi-step Form** or **Tabbed Interface**:
  - Tab 1: Patient Demographics (name, age, gender, ID, date)
  - Tab 2: Symptoms & Vitals (checkboxes, text areas)
  - Tab 3: Upload Lab Reports

- **Form Fields**:
  - Labels: text-sm font-medium mb-2
  - Inputs: rounded-md border px-4 py-2.5 text-base
  - Input groups in 2-column grid on desktop
  - Required field indicators
  - Helper text: text-xs below inputs

- **File Upload Zone**:
  - Drag-and-drop area: border-2 border-dashed rounded-lg p-8
  - Icon (Heroicons: document-arrow-up)
  - Supported formats displayed: PDF, CSV, TXT
  - File preview list with remove buttons

#### 4. Analysis Results Dashboard
- **Header Section**:
  - Patient info card (name, ID, age, date) - horizontal layout
  - Analysis timestamp and confidence score badge
  
- **Results Grid** (2-column desktop):
  - Left column: Lab values table with status indicators
  - Right column: AI insights and diagnostic suggestions

- **Lab Values Table**:
  - Test name | Value | Reference Range | Status
  - Status indicators using Heroicons (check-circle, exclamation-triangle, x-circle)
  - Font-mono for numerical values
  - Stripe pattern for rows (hover state)

- **Diagnostic Cards**:
  - Each condition in separate card: rounded-lg border p-6
  - Condition name: text-xl font-semibold
  - Confidence meter: Progress bar (h-2 rounded-full)
  - Severity badge: Small rounded-full px-3 py-1 text-xs uppercase

#### 5. Explainability Panel
- **Accordion Component** or **Expandable Sections**:
  - Each diagnostic suggestion has "View Explanation" button
  - Expands to show:
    - Key contributing factors (bulleted list)
    - Referenced lab values (highlighted)
    - Medical rationale (text-sm paragraph)
  
- **Factor Cards**:
  - Small cards (p-4) in grid layout
  - Factor name + importance indicator
  - Visual weight through icon size or badge

#### 6. Charts & Visualizations
- **Chart Types**:
  - Line charts: Trend over time for repeated tests
  - Bar charts: Comparison to reference ranges
  - Radial/gauge charts: Confidence scores
  - Use Chart.js or Recharts library

- **Chart Container**:
  - Rounded-lg border p-6
  - Chart title: text-lg font-semibold mb-4
  - Legend below chart

#### 7. PDF Report Generator
- **Report Preview Section**:
  - Preview pane showing report layout
  - Download button (primary, prominent)
  - Print option (secondary button)
  
- **Report Content Structure**:
  - Header with clinic/hospital name
  - Patient details section
  - Lab results table
  - AI analysis summary
  - Footer with disclaimers

#### 8. Buttons & Actions
- **Primary Button**: rounded-md px-6 py-2.5 text-base font-medium
- **Secondary Button**: rounded-md px-4 py-2 text-sm font-medium border
- **Icon Buttons**: p-2 rounded-md (for actions like edit, delete)
- Button groups: gap-4 spacing

#### 9. Status & Feedback Elements
- **Badges**: 
  - Rounded-full px-3 py-1 text-xs font-semibold uppercase
  - For status: Normal, Abnormal, Critical, Pending
  
- **Alerts/Notifications**:
  - Rounded-lg p-4 with icon (Heroicons)
  - Success, Warning, Error, Info variants
  
- **Progress Indicators**:
  - Linear progress bar for confidence scores
  - Spinner for loading states (analysis in progress)

#### 10. Data Tables
- **Table Structure**:
  - Full width, responsive (horizontal scroll on mobile)
  - Header: font-semibold text-sm uppercase
  - Rows: py-4 px-6 spacing
  - Hover state for rows
  - Sort indicators in headers

#### 11. Cards & Containers
- **Standard Card**:
  - rounded-lg border
  - p-6 for content
  - shadow-sm for subtle elevation
  
- **Stat Card** (dashboard):
  - Icon + Label + Value layout
  - Compact: p-4
  - Value: text-3xl font-bold

---

### D. Responsive Behavior

**Breakpoints**:
- Mobile: base (< 768px) - Single column, stacked layout
- Tablet: md (768px+) - 2-column grids, sidebar visible
- Desktop: lg (1024px+) - Multi-column dashboards, full feature set

**Mobile Adaptations**:
- Hamburger menu for navigation
- Stacked form fields
- Horizontal scroll for wide tables
- Bottom sheet for explainability panels

---

### E. Accessibility Standards

- All form inputs have associated labels
- Keyboard navigation support (tab order)
- ARIA labels for icon-only buttons
- Sufficient contrast ratios (WCAG AA minimum)
- Focus indicators visible on all interactive elements
- Screen reader friendly table markup
- Status indicators use both color AND icons/text

---

### F. Icons

**Library**: Heroicons (outline and solid variants via CDN)

**Key Icons**:
- document-arrow-up (upload)
- chart-bar (analytics)
- clipboard-document-list (reports)
- user-circle (patient)
- beaker (lab tests)
- check-circle, exclamation-triangle, x-circle (status)
- cog-6-tooth (settings)
- arrow-down-tray (download)

---

### G. Animations

**Minimal Usage**:
- Smooth transitions for tab/accordion expansion (duration-200)
- Fade-in for loading states (opacity transition)
- Subtle hover states (scale-[1.02] duration-150)
- NO complex scroll animations or parallax effects

---

## Images

**No hero images required** for this application. This is a professional medical tool focused on data and functionality.

**Image Usage**:
- Patient profile photos (optional, circular, w-12 h-12)
- Placeholder medical icons for empty states
- Logo/branding in header only

---

## Key Design Principles

1. **Clarity First**: Information hierarchy is paramount. Lab abnormalities must be immediately visible.
2. **Data Density**: Pack information efficiently without overwhelming. Use whitespace strategically.
3. **Trust & Professionalism**: Clean, consistent, reliable interface builds user confidence.
4. **Accessibility**: Medical tools must be usable by all practitioners.
5. **Scanability**: Doctors work quickly - design for rapid information gathering.