import jsPDF from "jspdf";
import autoTable from "jspdf-autotable";

interface PatientInfo {
  name: string;
  patientId: string;
  age: number;
  gender: string;
  date: string;
  analysisId: string;
}

interface LabValue {
  test: string;
  value: string;
  unit: string;
  referenceRange: string;
  status: "normal" | "abnormal" | "critical";
}

interface Diagnostic {
  condition: string;
  confidence: number;
  severity: "low" | "medium" | "high";
  description: string;
  keyFactors: string[];
}

interface Explanation {
  condition: string;
  reasoning: string;
  factors: Array<{
    name: string;
    importance: number;
    description: string;
  }>;
  references: string[];
}

interface ReportData {
  patient: PatientInfo;
  labValues: LabValue[];
  diagnostics: Diagnostic[];
  explanations: Explanation[];
  overallConfidence: number;
}

export function generatePDFReport(data: ReportData): void {
  const doc = new jsPDF();
  let yPos = 20;

  // Header
  doc.setFontSize(20);
  doc.setTextColor(37, 99, 235); // primary color
  doc.text("MedAI Diagnostics Report", 20, yPos);
  
  yPos += 10;
  doc.setFontSize(10);
  doc.setTextColor(100, 100, 100);
  doc.text("AI-Powered Patient Analysis & Diagnostic Insights", 20, yPos);
  
  // Separator line
  yPos += 5;
  doc.setDrawColor(200, 200, 200);
  doc.line(20, yPos, 190, yPos);
  
  // Patient Information Section
  yPos += 10;
  doc.setFontSize(14);
  doc.setTextColor(0, 0, 0);
  doc.text("Patient Information", 20, yPos);
  
  yPos += 8;
  doc.setFontSize(10);
  doc.text(`Name: ${data.patient.name}`, 20, yPos);
  doc.text(`Patient ID: ${data.patient.patientId}`, 120, yPos);
  
  yPos += 6;
  doc.text(`Age: ${data.patient.age} years`, 20, yPos);
  doc.text(`Gender: ${data.patient.gender}`, 120, yPos);
  
  yPos += 6;
  doc.text(`Analysis Date: ${data.patient.date}`, 20, yPos);
  doc.text(`Analysis ID: ${data.patient.analysisId}`, 120, yPos);
  
  yPos += 6;
  doc.text(`Overall Confidence: ${data.overallConfidence}%`, 20, yPos);
  
  // Lab Results Section
  yPos += 12;
  doc.setFontSize(14);
  doc.text("Laboratory Results", 20, yPos);
  
  yPos += 5;
  const labTableData = data.labValues.map((lab) => [
    lab.test,
    `${lab.value} ${lab.unit}`,
    lab.referenceRange,
    lab.status.toUpperCase(),
  ]);
  
  autoTable(doc, {
    startY: yPos,
    head: [["Test Name", "Value", "Reference Range", "Status"]],
    body: labTableData,
    theme: "striped",
    headStyles: { fillColor: [37, 99, 235] },
    didDrawCell: (data) => {
      if (data.section === "body" && data.column.index === 3) {
        const status = data.cell.raw as string;
        if (status === "CRITICAL") {
          doc.setTextColor(220, 38, 38);
        } else if (status === "ABNORMAL") {
          doc.setTextColor(234, 88, 12);
        } else {
          doc.setTextColor(34, 197, 94);
        }
      }
    },
    styles: { fontSize: 9 },
  });
  
  // @ts-ignore - autoTable adds finalY to doc
  yPos = doc.lastAutoTable.finalY + 12;
  
  // Check if we need a new page
  if (yPos > 250) {
    doc.addPage();
    yPos = 20;
  }
  
  // Diagnostic Suggestions Section
  doc.setFontSize(14);
  doc.setTextColor(0, 0, 0);
  doc.text("Diagnostic Suggestions", 20, yPos);
  
  yPos += 8;
  data.diagnostics.forEach((diagnostic, index) => {
    if (yPos > 260) {
      doc.addPage();
      yPos = 20;
    }
    
    doc.setFontSize(12);
    doc.setTextColor(37, 99, 235);
    doc.text(`${index + 1}. ${diagnostic.condition}`, 20, yPos);
    
    yPos += 6;
    doc.setFontSize(10);
    doc.setTextColor(0, 0, 0);
    doc.text(`Confidence: ${diagnostic.confidence}%`, 25, yPos);
    doc.text(`Severity: ${diagnostic.severity.toUpperCase()}`, 80, yPos);
    
    yPos += 6;
    const descLines = doc.splitTextToSize(diagnostic.description, 170);
    doc.text(descLines, 25, yPos);
    yPos += descLines.length * 5;
    
    yPos += 4;
    doc.setFontSize(9);
    doc.setTextColor(100, 100, 100);
    doc.text("Key Contributing Factors:", 25, yPos);
    yPos += 5;
    
    diagnostic.keyFactors.forEach((factor) => {
      if (yPos > 270) {
        doc.addPage();
        yPos = 20;
      }
      const factorLines = doc.splitTextToSize(`• ${factor}`, 165);
      doc.text(factorLines, 30, yPos);
      yPos += factorLines.length * 4.5;
    });
    
    yPos += 6;
  });
  
  // Explanations Section
  if (yPos > 220) {
    doc.addPage();
    yPos = 20;
  }
  
  yPos += 5;
  doc.setFontSize(14);
  doc.setTextColor(0, 0, 0);
  doc.text("AI Reasoning & Explanations", 20, yPos);
  
  yPos += 8;
  data.explanations.forEach((explanation, index) => {
    if (yPos > 250) {
      doc.addPage();
      yPos = 20;
    }
    
    doc.setFontSize(12);
    doc.setTextColor(37, 99, 235);
    doc.text(`${explanation.condition}`, 20, yPos);
    
    yPos += 6;
    doc.setFontSize(9);
    doc.setTextColor(100, 100, 100);
    doc.text("Medical Rationale:", 25, yPos);
    
    yPos += 5;
    doc.setTextColor(0, 0, 0);
    const reasoningLines = doc.splitTextToSize(explanation.reasoning, 165);
    doc.text(reasoningLines, 25, yPos);
    yPos += reasoningLines.length * 4.5;
    
    yPos += 4;
    doc.setTextColor(100, 100, 100);
    doc.text("Contributing Factors:", 25, yPos);
    yPos += 5;
    
    explanation.factors.forEach((factor) => {
      if (yPos > 270) {
        doc.addPage();
        yPos = 20;
      }
      doc.setTextColor(0, 0, 0);
      doc.text(`• ${factor.name} (${factor.importance}% importance)`, 30, yPos);
      yPos += 4;
      const factorDescLines = doc.splitTextToSize(factor.description, 160);
      doc.setTextColor(100, 100, 100);
      doc.text(factorDescLines, 35, yPos);
      yPos += factorDescLines.length * 4;
    });
    
    yPos += 6;
  });
  
  // Footer on every page
  const pageCount = doc.getNumberOfPages();
  for (let i = 1; i <= pageCount; i++) {
    doc.setPage(i);
    doc.setFontSize(8);
    doc.setTextColor(150, 150, 150);
    doc.text(
      `Generated by MedAI Diagnostics - Page ${i} of ${pageCount}`,
      20,
      285
    );
    doc.text(
      "This report is AI-generated and should be reviewed by a qualified healthcare professional.",
      20,
      290
    );
  }
  
  // Save the PDF
  const fileName = `MedAI_Report_${data.patient.patientId}_${data.patient.analysisId}.pdf`;
  doc.save(fileName);
}
