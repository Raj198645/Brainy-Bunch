import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { LabValuesTable } from "@/components/LabValuesTable";
import { DiagnosticCard } from "@/components/DiagnosticCard";
import { ExplainabilityPanel } from "@/components/ExplainabilityPanel";
import { LabValueComparisonChart } from "@/components/LabValueComparisonChart";
import { ReportPreview } from "@/components/ReportPreview";
import { Download, ArrowLeft, User, Calendar, Hash } from "lucide-react";
import { Link } from "wouter";
import { useToast } from "@/hooks/use-toast";
import { generatePDFReport } from "@/lib/pdfGenerator";

// todo: remove mock functionality
const mockPatientInfo = {
  name: "Sarah Johnson",
  patientId: "P-45821",
  age: 45,
  gender: "Female",
  date: "November 4, 2024",
  analysisId: "A-2024-001",
};

const mockLabValues = [
  {
    test: "White Blood Cell Count",
    value: "12.5",
    unit: "K/µL",
    referenceRange: "4.0-10.0 K/µL",
    status: "abnormal" as const,
  },
  {
    test: "Hemoglobin",
    value: "14.2",
    unit: "g/dL",
    referenceRange: "12.0-16.0 g/dL",
    status: "normal" as const,
  },
  {
    test: "Platelet Count",
    value: "85",
    unit: "K/µL",
    referenceRange: "150-400 K/µL",
    status: "critical" as const,
  },
  {
    test: "Blood Glucose",
    value: "126",
    unit: "mg/dL",
    referenceRange: "70-100 mg/dL",
    status: "abnormal" as const,
  },
  {
    test: "HbA1c",
    value: "7.2",
    unit: "%",
    referenceRange: "4.0-5.6%",
    status: "abnormal" as const,
  },
  {
    test: "Creatinine",
    value: "0.9",
    unit: "mg/dL",
    referenceRange: "0.6-1.2 mg/dL",
    status: "normal" as const,
  },
];

const mockDiagnostics = [
  {
    condition: "Type 2 Diabetes",
    confidence: 87,
    severity: "high" as const,
    description:
      "Elevated blood glucose levels suggest possible diabetes. Immediate medical consultation recommended.",
    keyFactors: [
      "Fasting glucose: 126 mg/dL (elevated)",
      "HbA1c: 7.2% (above normal range)",
      "Family history of diabetes",
      "BMI indicates overweight status",
    ],
  },
  {
    condition: "Thrombocytopenia",
    confidence: 82,
    severity: "high" as const,
    description:
      "Critically low platelet count requires immediate attention to prevent bleeding complications.",
    keyFactors: [
      "Platelet count: 85 K/µL (critically low)",
      "Risk of spontaneous bleeding",
      "Requires urgent hematology consultation",
    ],
  },
  {
    condition: "Mild Leukocytosis",
    confidence: 68,
    severity: "medium" as const,
    description:
      "Slightly elevated white blood cell count may indicate ongoing infection or inflammation.",
    keyFactors: [
      "WBC: 12.5 K/µL (moderately elevated)",
      "Patient reports fatigue symptoms",
      "Monitor for infection signs",
    ],
  },
];

const mockExplanations = [
  {
    condition: "Type 2 Diabetes",
    reasoning:
      "The combination of elevated fasting glucose levels (126 mg/dL), high HbA1c (7.2%), and patient's BMI suggests impaired glucose metabolism consistent with Type 2 Diabetes. The pattern indicates sustained hyperglycemia over the past 2-3 months.",
    factors: [
      {
        name: "Elevated Glucose",
        importance: 45,
        description: "Fasting glucose significantly above normal threshold",
      },
      {
        name: "High HbA1c",
        importance: 35,
        description: "Indicates poor long-term glucose control",
      },
      {
        name: "BMI Factor",
        importance: 15,
        description: "Increased insulin resistance risk",
      },
      {
        name: "Family History",
        importance: 5,
        description: "Genetic predisposition present",
      },
    ],
    references: [
      "Blood Glucose: 126 mg/dL (ref: 70-100 mg/dL)",
      "HbA1c: 7.2% (ref: 4.0-5.6%)",
      "BMI: 28.5 (overweight category)",
    ],
  },
  {
    condition: "Thrombocytopenia",
    reasoning:
      "Platelet count of 85 K/µL is significantly below the normal range, indicating thrombocytopenia. This requires urgent medical attention due to increased bleeding risk.",
    factors: [
      {
        name: "Low Platelets",
        importance: 85,
        description: "Primary diagnostic indicator",
      },
      {
        name: "Bleeding Risk",
        importance: 15,
        description: "Clinical significance assessment",
      },
    ],
    references: ["Platelet Count: 85 K/µL (ref: 150-400 K/µL)"],
  },
];

// todo: remove mock functionality
const mockLabComparisonData = [
  { test: "Glucose", value: 126, normal: 85, unit: "mg/dL" },
  { test: "Hemoglobin", value: 14.2, normal: 14.0, unit: "g/dL" },
  { test: "Platelets", value: 85, normal: 275, unit: "K/µL" },
  { test: "WBC Count", value: 12.5, normal: 7.0, unit: "K/µL" },
  { test: "HbA1c", value: 7.2, normal: 5.0, unit: "%" },
  { test: "Creatinine", value: 0.9, normal: 0.9, unit: "mg/dL" },
];

export default function AnalysisResults() {
  const { toast } = useToast();

  const handleDownloadReport = () => {
    try {
      console.log("Generating PDF report...");
      
      const reportData = {
        patient: mockPatientInfo,
        labValues: mockLabValues,
        diagnostics: mockDiagnostics,
        explanations: mockExplanations,
        overallConfidence: 87,
      };
      
      generatePDFReport(reportData);
      
      toast({
        title: "Report Downloaded",
        description: "Your PDF report has been downloaded successfully.",
      });
    } catch (error) {
      console.error("Error generating PDF:", error);
      toast({
        title: "Error",
        description: "Failed to generate PDF report. Please try again.",
        variant: "destructive",
      });
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between gap-4 flex-wrap">
        <div className="flex items-center gap-4">
          <Link href="/">
            <Button variant="ghost" size="icon" data-testid="button-back">
              <ArrowLeft className="h-5 w-5" />
            </Button>
          </Link>
          <div>
            <h1 className="text-3xl font-bold">Analysis Results</h1>
            <p className="text-muted-foreground mt-1">
              AI-powered diagnostic insights and recommendations
            </p>
          </div>
        </div>
        <Button onClick={handleDownloadReport} data-testid="button-download-report">
          <Download className="h-4 w-4 mr-2" />
          Download Report
        </Button>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Patient Information</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <div className="flex items-center gap-3">
              <div className="h-10 w-10 rounded-md bg-primary/10 flex items-center justify-center">
                <User className="h-5 w-5 text-primary" />
              </div>
              <div>
                <p className="text-xs text-muted-foreground">Patient Name</p>
                <p className="font-medium" data-testid="text-patient-name">
                  {mockPatientInfo.name}
                </p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <div className="h-10 w-10 rounded-md bg-primary/10 flex items-center justify-center">
                <Hash className="h-5 w-5 text-primary" />
              </div>
              <div>
                <p className="text-xs text-muted-foreground">Patient ID</p>
                <p className="font-mono font-medium" data-testid="text-patient-id">
                  {mockPatientInfo.patientId}
                </p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <div className="h-10 w-10 rounded-md bg-primary/10 flex items-center justify-center">
                <Calendar className="h-5 w-5 text-primary" />
              </div>
              <div>
                <p className="text-xs text-muted-foreground">Analysis Date</p>
                <p className="font-medium">{mockPatientInfo.date}</p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <div>
                <p className="text-xs text-muted-foreground">Overall Confidence</p>
                <div className="flex items-center gap-2">
                  <p className="font-mono text-xl font-bold">87%</p>
                  <Badge variant="outline" className="bg-chart-2/10 text-chart-2 border-chart-2/20">
                    High
                  </Badge>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      <LabValueComparisonChart data={mockLabComparisonData} />

      <ReportPreview
        patientName={mockPatientInfo.name}
        patientId={mockPatientInfo.patientId}
        analysisId={mockPatientInfo.analysisId}
        date={mockPatientInfo.date}
        findings={mockDiagnostics.length}
        confidence={87}
        onDownload={handleDownloadReport}
      />

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Lab Results</CardTitle>
            </CardHeader>
            <CardContent>
              <LabValuesTable values={mockLabValues} />
            </CardContent>
          </Card>
        </div>

        <div className="space-y-6">
          <h2 className="text-xl font-semibold">Diagnostic Suggestions</h2>
          {mockDiagnostics.map((diagnostic, index) => (
            <DiagnosticCard key={index} {...diagnostic} />
          ))}
        </div>
      </div>

      <ExplainabilityPanel explanations={mockExplanations} />
    </div>
  );
}
