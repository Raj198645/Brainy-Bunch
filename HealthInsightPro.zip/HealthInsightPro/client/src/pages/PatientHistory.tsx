import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Search, Eye, Calendar, Activity } from "lucide-react";
import { Link } from "wouter";

// todo: remove mock functionality
const mockPatients = [
  {
    id: "P-45821",
    name: "Sarah Johnson",
    age: 45,
    gender: "Female",
    lastVisit: "2024-11-04",
    totalAnalyses: 8,
    status: "active",
    recentConditions: ["Type 2 Diabetes", "Thrombocytopenia"],
  },
  {
    id: "P-45822",
    name: "Michael Chen",
    age: 52,
    gender: "Male",
    lastVisit: "2024-11-04",
    totalAnalyses: 12,
    status: "active",
    recentConditions: ["Hypertension"],
  },
  {
    id: "P-45823",
    name: "Emily Rodriguez",
    age: 38,
    gender: "Female",
    lastVisit: "2024-11-04",
    totalAnalyses: 5,
    status: "active",
    recentConditions: ["Anemia", "Vitamin D Deficiency"],
  },
  {
    id: "P-45824",
    name: "David Kim",
    age: 61,
    gender: "Male",
    lastVisit: "2024-11-03",
    totalAnalyses: 15,
    status: "active",
    recentConditions: ["Type 2 Diabetes", "Hyperlipidemia"],
  },
  {
    id: "P-45825",
    name: "Jennifer Martinez",
    age: 29,
    gender: "Female",
    lastVisit: "2024-11-02",
    totalAnalyses: 3,
    status: "active",
    recentConditions: ["Hypothyroidism"],
  },
  {
    id: "P-45826",
    name: "Robert Taylor",
    age: 55,
    gender: "Male",
    lastVisit: "2024-11-01",
    totalAnalyses: 9,
    status: "inactive",
    recentConditions: ["Chronic Kidney Disease"],
  },
];

export default function PatientHistory() {
  const [searchQuery, setSearchQuery] = useState("");

  const filteredPatients = mockPatients.filter(
    (patient) =>
      patient.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      patient.id.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">Patient History</h1>
        <p className="text-muted-foreground mt-1">
          View all patients and their analysis history
        </p>
      </div>

      <Card>
        <CardHeader>
          <div className="flex items-center justify-between gap-4 flex-wrap">
            <CardTitle>All Patients ({filteredPatients.length})</CardTitle>
            <div className="relative w-full md:w-80">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search by name or ID..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-9"
                data-testid="input-search-patients"
              />
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {filteredPatients.map((patient, index) => (
              <Card key={patient.id} data-testid={`card-patient-${index}`}>
                <CardContent className="p-6">
                  <div className="flex items-start justify-between gap-4 flex-wrap">
                    <div className="flex-1 space-y-3">
                      <div className="flex items-center gap-3 flex-wrap">
                        <h3 className="text-lg font-semibold">{patient.name}</h3>
                        <Badge
                          variant="outline"
                          className="font-mono"
                          data-testid={`badge-patient-id-${index}`}
                        >
                          {patient.id}
                        </Badge>
                        {patient.status === "active" ? (
                          <Badge variant="outline" className="bg-chart-2/10 text-chart-2 border-chart-2/20">
                            Active
                          </Badge>
                        ) : (
                          <Badge variant="outline" className="bg-muted/50 text-muted-foreground border-muted">
                            Inactive
                          </Badge>
                        )}
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                        <div>
                          <p className="text-muted-foreground">Demographics</p>
                          <p className="font-medium">
                            {patient.age} years • {patient.gender}
                          </p>
                        </div>
                        <div className="flex items-center gap-2">
                          <Calendar className="h-4 w-4 text-muted-foreground" />
                          <div>
                            <p className="text-muted-foreground">Last Visit</p>
                            <p className="font-medium">{patient.lastVisit}</p>
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <Activity className="h-4 w-4 text-muted-foreground" />
                          <div>
                            <p className="text-muted-foreground">Total Analyses</p>
                            <p className="font-medium">{patient.totalAnalyses}</p>
                          </div>
                        </div>
                      </div>

                      {patient.recentConditions.length > 0 && (
                        <div>
                          <p className="text-sm text-muted-foreground mb-2">
                            Recent Conditions
                          </p>
                          <div className="flex flex-wrap gap-2">
                            {patient.recentConditions.map((condition, cIndex) => (
                              <Badge
                                key={cIndex}
                                variant="outline"
                                className="bg-chart-4/10 text-chart-4 border-chart-4/20"
                              >
                                {condition}
                              </Badge>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>

                    <Button
                      variant="outline"
                      onClick={() => console.log("View patient:", patient.id)}
                      data-testid={`button-view-patient-${index}`}
                    >
                      <Eye className="h-4 w-4 mr-2" />
                      View Details
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
