import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { FileUploadZone } from "@/components/FileUploadZone";
import { ArrowLeft, ArrowRight, Sparkles } from "lucide-react";
import { Link, useLocation } from "wouter";
import { useToast } from "@/hooks/use-toast";

export default function NewAnalysis() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState("demographics");
  const [formData, setFormData] = useState({
    name: "",
    age: "",
    gender: "",
    patientId: "",
    symptoms: "",
    bloodPressure: "",
    heartRate: "",
    temperature: "",
    weight: "",
  });

  const handleInputChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
    console.log(`${e.target.name} changed to:`, e.target.value);
  };

  const handleGenderChange = (value: string) => {
    setFormData({
      ...formData,
      gender: value,
    });
    console.log("Gender changed to:", value);
  };

  const handleAnalyze = () => {
    console.log("Analyzing patient data:", formData);
    toast({
      title: "Analysis Started",
      description: "AI is analyzing the patient data and lab reports...",
    });
    setTimeout(() => {
      setLocation("/results");
    }, 1500);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-4">
        <Link href="/">
          <Button variant="ghost" size="icon" data-testid="button-back">
            <ArrowLeft className="h-5 w-5" />
          </Button>
        </Link>
        <div>
          <h1 className="text-3xl font-bold">New Patient Analysis</h1>
          <p className="text-muted-foreground mt-1">
            Enter patient information and upload lab reports
          </p>
        </div>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="demographics" data-testid="tab-demographics">
            Demographics
          </TabsTrigger>
          <TabsTrigger value="vitals" data-testid="tab-vitals">
            Vitals & Symptoms
          </TabsTrigger>
          <TabsTrigger value="upload" data-testid="tab-upload">
            Lab Reports
          </TabsTrigger>
        </TabsList>

        <TabsContent value="demographics" className="space-y-6 mt-6">
          <Card>
            <CardHeader>
              <CardTitle>Patient Demographics</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label htmlFor="name">Full Name *</Label>
                  <Input
                    id="name"
                    name="name"
                    placeholder="John Doe"
                    value={formData.name}
                    onChange={handleInputChange}
                    data-testid="input-name"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="patientId">Patient ID *</Label>
                  <Input
                    id="patientId"
                    name="patientId"
                    placeholder="P-12345"
                    value={formData.patientId}
                    onChange={handleInputChange}
                    data-testid="input-patient-id"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="age">Age *</Label>
                  <Input
                    id="age"
                    name="age"
                    type="number"
                    placeholder="35"
                    value={formData.age}
                    onChange={handleInputChange}
                    data-testid="input-age"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="gender">Gender *</Label>
                  <Select value={formData.gender} onValueChange={handleGenderChange}>
                    <SelectTrigger data-testid="select-gender">
                      <SelectValue placeholder="Select gender" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="male">Male</SelectItem>
                      <SelectItem value="female">Female</SelectItem>
                      <SelectItem value="other">Other</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </CardContent>
          </Card>

          <div className="flex justify-end">
            <Button
              onClick={() => setActiveTab("vitals")}
              data-testid="button-next-vitals"
            >
              Next: Vitals & Symptoms
              <ArrowRight className="h-4 w-4 ml-2" />
            </Button>
          </div>
        </TabsContent>

        <TabsContent value="vitals" className="space-y-6 mt-6">
          <Card>
            <CardHeader>
              <CardTitle>Vital Signs</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label htmlFor="bloodPressure">Blood Pressure (mmHg)</Label>
                  <Input
                    id="bloodPressure"
                    name="bloodPressure"
                    placeholder="120/80"
                    value={formData.bloodPressure}
                    onChange={handleInputChange}
                    data-testid="input-blood-pressure"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="heartRate">Heart Rate (bpm)</Label>
                  <Input
                    id="heartRate"
                    name="heartRate"
                    type="number"
                    placeholder="72"
                    value={formData.heartRate}
                    onChange={handleInputChange}
                    data-testid="input-heart-rate"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="temperature">Temperature (°F)</Label>
                  <Input
                    id="temperature"
                    name="temperature"
                    placeholder="98.6"
                    value={formData.temperature}
                    onChange={handleInputChange}
                    data-testid="input-temperature"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="weight">Weight (lbs)</Label>
                  <Input
                    id="weight"
                    name="weight"
                    type="number"
                    placeholder="150"
                    value={formData.weight}
                    onChange={handleInputChange}
                    data-testid="input-weight"
                  />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Symptoms & Notes</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <Label htmlFor="symptoms">Current Symptoms</Label>
                <Textarea
                  id="symptoms"
                  name="symptoms"
                  placeholder="Describe any symptoms the patient is experiencing..."
                  value={formData.symptoms}
                  onChange={handleInputChange}
                  rows={4}
                  data-testid="input-symptoms"
                />
              </div>
            </CardContent>
          </Card>

          <div className="flex justify-between gap-4">
            <Button
              variant="outline"
              onClick={() => setActiveTab("demographics")}
              data-testid="button-back-demographics"
            >
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back
            </Button>
            <Button
              onClick={() => setActiveTab("upload")}
              data-testid="button-next-upload"
            >
              Next: Upload Reports
              <ArrowRight className="h-4 w-4 ml-2" />
            </Button>
          </div>
        </TabsContent>

        <TabsContent value="upload" className="space-y-6 mt-6">
          <Card>
            <CardHeader>
              <CardTitle>Upload Lab Reports</CardTitle>
            </CardHeader>
            <CardContent>
              <FileUploadZone />
            </CardContent>
          </Card>

          <div className="flex justify-between gap-4">
            <Button
              variant="outline"
              onClick={() => setActiveTab("vitals")}
              data-testid="button-back-vitals"
            >
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back
            </Button>
            <Button onClick={handleAnalyze} data-testid="button-analyze">
              <Sparkles className="h-4 w-4 mr-2" />
              Analyze with AI
            </Button>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
