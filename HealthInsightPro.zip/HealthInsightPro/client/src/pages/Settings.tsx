import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import { Save, Bell, Shield, Database, Zap } from "lucide-react";

export default function Settings() {
  const { toast } = useToast();
  const [settings, setSettings] = useState({
    // General settings
    clinicName: "MedAI Diagnostics Center",
    email: "admin@medai.com",
    timezone: "America/New_York",
    
    // Notification settings
    emailNotifications: true,
    analysisComplete: true,
    criticalFindings: true,
    weeklyReports: false,
    
    // AI settings
    confidenceThreshold: "75",
    autoAnalysis: false,
    detailedExplanations: true,
    
    // Privacy settings
    dataRetention: "90",
    anonymizeReports: false,
    shareAnalytics: true,
  });

  const handleSave = () => {
    console.log("Saving settings:", settings);
    toast({
      title: "Settings Saved",
      description: "Your preferences have been updated successfully.",
    });
  };

  const updateSetting = (key: string, value: any) => {
    setSettings((prev) => ({ ...prev, [key]: value }));
    console.log(`Setting ${key} updated to:`, value);
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">Settings</h1>
        <p className="text-muted-foreground mt-1">
          Manage your application preferences and configuration
        </p>
      </div>

      <Tabs defaultValue="general">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="general" data-testid="tab-general">
            General
          </TabsTrigger>
          <TabsTrigger value="notifications" data-testid="tab-notifications">
            Notifications
          </TabsTrigger>
          <TabsTrigger value="ai" data-testid="tab-ai">
            AI Settings
          </TabsTrigger>
          <TabsTrigger value="privacy" data-testid="tab-privacy">
            Privacy
          </TabsTrigger>
        </TabsList>

        <TabsContent value="general" className="space-y-6 mt-6">
          <Card>
            <CardHeader>
              <CardTitle>General Settings</CardTitle>
              <CardDescription>
                Configure basic application settings and preferences
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="clinicName">Clinic/Hospital Name</Label>
                <Input
                  id="clinicName"
                  value={settings.clinicName}
                  onChange={(e) => updateSetting("clinicName", e.target.value)}
                  data-testid="input-clinic-name"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="email">Administrator Email</Label>
                <Input
                  id="email"
                  type="email"
                  value={settings.email}
                  onChange={(e) => updateSetting("email", e.target.value)}
                  data-testid="input-email"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="timezone">Timezone</Label>
                <Select
                  value={settings.timezone}
                  onValueChange={(value) => updateSetting("timezone", value)}
                >
                  <SelectTrigger data-testid="select-timezone">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="America/New_York">Eastern Time (ET)</SelectItem>
                    <SelectItem value="America/Chicago">Central Time (CT)</SelectItem>
                    <SelectItem value="America/Denver">Mountain Time (MT)</SelectItem>
                    <SelectItem value="America/Los_Angeles">Pacific Time (PT)</SelectItem>
                    <SelectItem value="UTC">UTC</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="notifications" className="space-y-6 mt-6">
          <Card>
            <CardHeader>
              <div className="flex items-center gap-2">
                <Bell className="h-5 w-5 text-primary" />
                <CardTitle>Notification Preferences</CardTitle>
              </div>
              <CardDescription>
                Choose when and how you want to be notified
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex items-center justify-between gap-4">
                <div className="space-y-1">
                  <Label htmlFor="emailNotifications">Email Notifications</Label>
                  <p className="text-sm text-muted-foreground">
                    Receive notifications via email
                  </p>
                </div>
                <Switch
                  id="emailNotifications"
                  checked={settings.emailNotifications}
                  onCheckedChange={(checked) =>
                    updateSetting("emailNotifications", checked)
                  }
                  data-testid="switch-email-notifications"
                />
              </div>

              <div className="flex items-center justify-between gap-4">
                <div className="space-y-1">
                  <Label htmlFor="analysisComplete">Analysis Completion</Label>
                  <p className="text-sm text-muted-foreground">
                    Notify when AI analysis is complete
                  </p>
                </div>
                <Switch
                  id="analysisComplete"
                  checked={settings.analysisComplete}
                  onCheckedChange={(checked) =>
                    updateSetting("analysisComplete", checked)
                  }
                  data-testid="switch-analysis-complete"
                />
              </div>

              <div className="flex items-center justify-between gap-4">
                <div className="space-y-1">
                  <Label htmlFor="criticalFindings">Critical Findings Alert</Label>
                  <p className="text-sm text-muted-foreground">
                    Immediate alerts for critical health findings
                  </p>
                </div>
                <Switch
                  id="criticalFindings"
                  checked={settings.criticalFindings}
                  onCheckedChange={(checked) =>
                    updateSetting("criticalFindings", checked)
                  }
                  data-testid="switch-critical-findings"
                />
              </div>

              <div className="flex items-center justify-between gap-4">
                <div className="space-y-1">
                  <Label htmlFor="weeklyReports">Weekly Summary Reports</Label>
                  <p className="text-sm text-muted-foreground">
                    Receive weekly analytics and insights
                  </p>
                </div>
                <Switch
                  id="weeklyReports"
                  checked={settings.weeklyReports}
                  onCheckedChange={(checked) =>
                    updateSetting("weeklyReports", checked)
                  }
                  data-testid="switch-weekly-reports"
                />
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="ai" className="space-y-6 mt-6">
          <Card>
            <CardHeader>
              <div className="flex items-center gap-2">
                <Zap className="h-5 w-5 text-primary" />
                <CardTitle>AI Engine Configuration</CardTitle>
              </div>
              <CardDescription>
                Configure AI analysis parameters and behavior
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="confidenceThreshold">
                  Minimum Confidence Threshold ({settings.confidenceThreshold}%)
                </Label>
                <Input
                  id="confidenceThreshold"
                  type="range"
                  min="50"
                  max="95"
                  value={settings.confidenceThreshold}
                  onChange={(e) =>
                    updateSetting("confidenceThreshold", e.target.value)
                  }
                  className="cursor-pointer"
                  data-testid="input-confidence-threshold"
                />
                <p className="text-sm text-muted-foreground">
                  Only show diagnostic suggestions above this confidence level
                </p>
              </div>

              <div className="flex items-center justify-between gap-4">
                <div className="space-y-1">
                  <Label htmlFor="autoAnalysis">Automatic Analysis</Label>
                  <p className="text-sm text-muted-foreground">
                    Start analysis automatically when reports are uploaded
                  </p>
                </div>
                <Switch
                  id="autoAnalysis"
                  checked={settings.autoAnalysis}
                  onCheckedChange={(checked) =>
                    updateSetting("autoAnalysis", checked)
                  }
                  data-testid="switch-auto-analysis"
                />
              </div>

              <div className="flex items-center justify-between gap-4">
                <div className="space-y-1">
                  <Label htmlFor="detailedExplanations">Detailed Explanations</Label>
                  <p className="text-sm text-muted-foreground">
                    Include comprehensive reasoning for all findings
                  </p>
                </div>
                <Switch
                  id="detailedExplanations"
                  checked={settings.detailedExplanations}
                  onCheckedChange={(checked) =>
                    updateSetting("detailedExplanations", checked)
                  }
                  data-testid="switch-detailed-explanations"
                />
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="privacy" className="space-y-6 mt-6">
          <Card>
            <CardHeader>
              <div className="flex items-center gap-2">
                <Shield className="h-5 w-5 text-primary" />
                <CardTitle>Privacy & Data Management</CardTitle>
              </div>
              <CardDescription>
                Control how your data is stored and used
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="dataRetention">Data Retention Period (days)</Label>
                <Select
                  value={settings.dataRetention}
                  onValueChange={(value) => updateSetting("dataRetention", value)}
                >
                  <SelectTrigger data-testid="select-data-retention">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="30">30 days</SelectItem>
                    <SelectItem value="90">90 days</SelectItem>
                    <SelectItem value="180">180 days</SelectItem>
                    <SelectItem value="365">1 year</SelectItem>
                    <SelectItem value="unlimited">Unlimited</SelectItem>
                  </SelectContent>
                </Select>
                <p className="text-sm text-muted-foreground">
                  Patient data will be automatically archived after this period
                </p>
              </div>

              <div className="flex items-center justify-between gap-4">
                <div className="space-y-1">
                  <Label htmlFor="anonymizeReports">Anonymize Exported Reports</Label>
                  <p className="text-sm text-muted-foreground">
                    Remove patient identifiers from downloaded reports
                  </p>
                </div>
                <Switch
                  id="anonymizeReports"
                  checked={settings.anonymizeReports}
                  onCheckedChange={(checked) =>
                    updateSetting("anonymizeReports", checked)
                  }
                  data-testid="switch-anonymize-reports"
                />
              </div>

              <div className="flex items-center justify-between gap-4">
                <div className="space-y-1">
                  <Label htmlFor="shareAnalytics">Share Anonymous Analytics</Label>
                  <p className="text-sm text-muted-foreground">
                    Help improve AI accuracy by sharing anonymized data
                  </p>
                </div>
                <Switch
                  id="shareAnalytics"
                  checked={settings.shareAnalytics}
                  onCheckedChange={(checked) =>
                    updateSetting("shareAnalytics", checked)
                  }
                  data-testid="switch-share-analytics"
                />
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      <div className="flex justify-end">
        <Button onClick={handleSave} data-testid="button-save-settings">
          <Save className="h-4 w-4 mr-2" />
          Save Settings
        </Button>
      </div>
    </div>
  );
}
