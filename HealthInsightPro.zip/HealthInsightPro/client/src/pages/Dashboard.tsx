import { Users, Activity, TrendingUp, FileText, Clock } from "lucide-react";
import { StatCard } from "@/components/StatCard";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { AnalysisTrendChart } from "@/components/AnalysisTrendChart";
import { FindingsDistributionChart } from "@/components/FindingsDistributionChart";
import { AccuracyMetricsChart } from "@/components/AccuracyMetricsChart";

// todo: remove mock functionality
const recentAnalyses = [
  {
    id: "A-2024-001",
    patientName: "Sarah Johnson",
    patientId: "P-45821",
    date: "2024-11-04 09:23 AM",
    confidence: 89,
    status: "completed",
    findings: 2,
  },
  {
    id: "A-2024-002",
    patientName: "Michael Chen",
    patientId: "P-45822",
    date: "2024-11-04 10:15 AM",
    confidence: 94,
    status: "completed",
    findings: 1,
  },
  {
    id: "A-2024-003",
    patientName: "Emily Rodriguez",
    patientId: "P-45823",
    date: "2024-11-04 11:42 AM",
    confidence: 76,
    status: "completed",
    findings: 3,
  },
  {
    id: "A-2024-004",
    patientName: "David Kim",
    patientId: "P-45824",
    date: "2024-11-04 02:18 PM",
    confidence: 91,
    status: "processing",
    findings: 0,
  },
];

export default function Dashboard() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between gap-4 flex-wrap">
        <div>
          <h1 className="text-3xl font-bold">Dashboard</h1>
          <p className="text-muted-foreground mt-1">
            Overview of your diagnostic analyses
          </p>
        </div>
        <Link href="/new-analysis">
          <Button data-testid="button-new-analysis">
            <FileText className="h-4 w-4 mr-2" />
            New Analysis
          </Button>
        </Link>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard
          title="Total Patients"
          value="1,234"
          icon={Users}
          trend="+12% from last month"
          trendUp={true}
        />
        <StatCard
          title="Analyses Today"
          value="48"
          icon={Activity}
          trend="+8% from yesterday"
          trendUp={true}
        />
        <StatCard
          title="Accuracy Rate"
          value="94.5%"
          icon={TrendingUp}
          trend="+2.1% improvement"
          trendUp={true}
        />
        <StatCard
          title="Reports Generated"
          value="892"
          icon={FileText}
          trend="+18% this week"
          trendUp={true}
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <AnalysisTrendChart />
        <FindingsDistributionChart />
      </div>

      <AccuracyMetricsChart />

      <Card>
        <CardHeader>
          <CardTitle>Recent Analyses</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="border-b">
                <tr>
                  <th className="text-left p-4 text-sm font-semibold">Analysis ID</th>
                  <th className="text-left p-4 text-sm font-semibold">Patient</th>
                  <th className="text-left p-4 text-sm font-semibold">Date & Time</th>
                  <th className="text-left p-4 text-sm font-semibold">Confidence</th>
                  <th className="text-left p-4 text-sm font-semibold">Findings</th>
                  <th className="text-left p-4 text-sm font-semibold">Status</th>
                  <th className="text-left p-4 text-sm font-semibold">Actions</th>
                </tr>
              </thead>
              <tbody>
                {recentAnalyses.map((analysis, index) => (
                  <tr
                    key={analysis.id}
                    className="border-b hover-elevate"
                    data-testid={`row-analysis-${index}`}
                  >
                    <td className="p-4">
                      <span className="font-mono text-sm font-medium">
                        {analysis.id}
                      </span>
                    </td>
                    <td className="p-4">
                      <div>
                        <p className="text-sm font-medium">{analysis.patientName}</p>
                        <p className="text-xs text-muted-foreground font-mono">
                          {analysis.patientId}
                        </p>
                      </div>
                    </td>
                    <td className="p-4">
                      <div className="flex items-center gap-2">
                        <Clock className="h-4 w-4 text-muted-foreground" />
                        <span className="text-sm">{analysis.date}</span>
                      </div>
                    </td>
                    <td className="p-4">
                      <span className="font-mono font-semibold">
                        {analysis.confidence}%
                      </span>
                    </td>
                    <td className="p-4">
                      <Badge variant="outline">{analysis.findings} findings</Badge>
                    </td>
                    <td className="p-4">
                      {analysis.status === "completed" ? (
                        <Badge variant="outline" className="bg-chart-2/10 text-chart-2 border-chart-2/20">
                          Completed
                        </Badge>
                      ) : (
                        <Badge variant="outline" className="bg-chart-1/10 text-chart-1 border-chart-1/20">
                          Processing
                        </Badge>
                      )}
                    </td>
                    <td className="p-4">
                      <Button variant="outline" size="sm" data-testid={`button-view-${index}`}>
                        View
                      </Button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
