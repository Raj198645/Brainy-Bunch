import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Download, FileText, Calendar, Filter } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

// todo: remove mock functionality
const mockReports = [
  {
    id: "R-2024-089",
    analysisId: "A-2024-001",
    patientName: "Sarah Johnson",
    patientId: "P-45821",
    date: "2024-11-04",
    time: "09:23 AM",
    type: "Full Diagnostic Report",
    findings: 2,
    pages: 5,
    status: "completed",
  },
  {
    id: "R-2024-090",
    analysisId: "A-2024-002",
    patientName: "Michael Chen",
    patientId: "P-45822",
    date: "2024-11-04",
    time: "10:15 AM",
    type: "Lab Results Summary",
    findings: 1,
    pages: 3,
    status: "completed",
  },
  {
    id: "R-2024-091",
    analysisId: "A-2024-003",
    patientName: "Emily Rodriguez",
    patientId: "P-45823",
    date: "2024-11-04",
    time: "11:42 AM",
    type: "Full Diagnostic Report",
    findings: 3,
    pages: 7,
    status: "completed",
  },
  {
    id: "R-2024-092",
    analysisId: "A-2024-004",
    patientName: "David Kim",
    patientId: "P-45824",
    date: "2024-11-04",
    time: "02:18 PM",
    type: "Full Diagnostic Report",
    findings: 2,
    pages: 6,
    status: "generating",
  },
  {
    id: "R-2024-088",
    analysisId: "A-2024-000",
    patientName: "Jennifer Martinez",
    patientId: "P-45825",
    date: "2024-11-03",
    time: "03:45 PM",
    type: "Lab Results Summary",
    findings: 1,
    pages: 2,
    status: "completed",
  },
];

export default function Reports() {
  const { toast } = useToast();
  const [filterType, setFilterType] = useState("all");
  const [filterStatus, setFilterStatus] = useState("all");

  const filteredReports = mockReports.filter((report) => {
    const typeMatch = filterType === "all" || report.type === filterType;
    const statusMatch = filterStatus === "all" || report.status === filterStatus;
    return typeMatch && statusMatch;
  });

  const handleDownload = (reportId: string) => {
    console.log("Downloading report:", reportId);
    toast({
      title: "Report Downloaded",
      description: `Report ${reportId} has been downloaded successfully.`,
    });
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">Reports</h1>
        <p className="text-muted-foreground mt-1">
          View and download generated diagnostic reports
        </p>
      </div>

      <Card>
        <CardHeader>
          <div className="flex items-center justify-between gap-4 flex-wrap">
            <CardTitle>All Reports ({filteredReports.length})</CardTitle>
            <div className="flex items-center gap-3 flex-wrap">
              <div className="flex items-center gap-2">
                <Filter className="h-4 w-4 text-muted-foreground" />
                <Select value={filterType} onValueChange={setFilterType}>
                  <SelectTrigger className="w-48" data-testid="select-filter-type">
                    <SelectValue placeholder="Filter by type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Types</SelectItem>
                    <SelectItem value="Full Diagnostic Report">Full Diagnostic</SelectItem>
                    <SelectItem value="Lab Results Summary">Lab Summary</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <Select value={filterStatus} onValueChange={setFilterStatus}>
                <SelectTrigger className="w-40" data-testid="select-filter-status">
                  <SelectValue placeholder="Filter by status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Status</SelectItem>
                  <SelectItem value="completed">Completed</SelectItem>
                  <SelectItem value="generating">Generating</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="border-b">
                <tr>
                  <th className="text-left p-4 text-sm font-semibold">Report ID</th>
                  <th className="text-left p-4 text-sm font-semibold">Patient</th>
                  <th className="text-left p-4 text-sm font-semibold">Date & Time</th>
                  <th className="text-left p-4 text-sm font-semibold">Type</th>
                  <th className="text-left p-4 text-sm font-semibold">Findings</th>
                  <th className="text-left p-4 text-sm font-semibold">Pages</th>
                  <th className="text-left p-4 text-sm font-semibold">Status</th>
                  <th className="text-left p-4 text-sm font-semibold">Actions</th>
                </tr>
              </thead>
              <tbody>
                {filteredReports.map((report, index) => (
                  <tr
                    key={report.id}
                    className="border-b hover-elevate"
                    data-testid={`row-report-${index}`}
                  >
                    <td className="p-4">
                      <div className="flex items-center gap-2">
                        <FileText className="h-4 w-4 text-muted-foreground" />
                        <span className="font-mono text-sm font-medium">
                          {report.id}
                        </span>
                      </div>
                    </td>
                    <td className="p-4">
                      <div>
                        <p className="text-sm font-medium">{report.patientName}</p>
                        <p className="text-xs text-muted-foreground font-mono">
                          {report.patientId}
                        </p>
                      </div>
                    </td>
                    <td className="p-4">
                      <div className="flex items-center gap-2">
                        <Calendar className="h-4 w-4 text-muted-foreground" />
                        <div>
                          <p className="text-sm">{report.date}</p>
                          <p className="text-xs text-muted-foreground">{report.time}</p>
                        </div>
                      </div>
                    </td>
                    <td className="p-4">
                      <Badge variant="outline">{report.type}</Badge>
                    </td>
                    <td className="p-4">
                      <span className="text-sm font-medium">
                        {report.findings} findings
                      </span>
                    </td>
                    <td className="p-4">
                      <span className="text-sm text-muted-foreground">
                        {report.pages} pages
                      </span>
                    </td>
                    <td className="p-4">
                      {report.status === "completed" ? (
                        <Badge variant="outline" className="bg-chart-2/10 text-chart-2 border-chart-2/20">
                          Completed
                        </Badge>
                      ) : (
                        <Badge variant="outline" className="bg-chart-1/10 text-chart-1 border-chart-1/20">
                          Generating
                        </Badge>
                      )}
                    </td>
                    <td className="p-4">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleDownload(report.id)}
                        disabled={report.status !== "completed"}
                        data-testid={`button-download-${index}`}
                      >
                        <Download className="h-4 w-4 mr-2" />
                        Download
                      </Button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
