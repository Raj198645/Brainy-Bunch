import NewAnalysis from "../NewAnalysis";

export default function NewAnalysisExample() {
  return <NewAnalysis />;
}
