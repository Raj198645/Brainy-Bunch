import AnalysisResults from "../AnalysisResults";

export default function AnalysisResultsExample() {
  return <AnalysisResults />;
}
