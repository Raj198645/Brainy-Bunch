import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Legend,
  ReferenceLine,
} from "recharts";

interface LabData {
  test: string;
  value: number;
  normal: number;
  unit: string;
}

interface LabValueComparisonChartProps {
  data: LabData[];
}

export function LabValueComparisonChart({ data }: LabValueComparisonChartProps) {
  return (
    <Card data-testid="chart-lab-comparison">
      <CardHeader>
        <CardTitle>Lab Values vs Normal Range</CardTitle>
      </CardHeader>
      <CardContent>
        <ResponsiveContainer width="100%" height={350}>
          <BarChart data={data} layout="vertical">
            <CartesianGrid strokeDasharray="3 3" className="stroke-border" />
            <XAxis
              type="number"
              className="text-xs"
              tick={{ fill: "hsl(var(--muted-foreground))" }}
            />
            <YAxis
              dataKey="test"
              type="category"
              width={150}
              className="text-xs"
              tick={{ fill: "hsl(var(--muted-foreground))" }}
            />
            <Tooltip
              contentStyle={{
                backgroundColor: "hsl(var(--popover))",
                border: "1px solid hsl(var(--border))",
                borderRadius: "6px",
              }}
              formatter={(value: number, name: string) => {
                const item = data.find(d => d.value === value || d.normal === value);
                return [`${value} ${item?.unit || ''}`, name];
              }}
            />
            <Legend />
            <Bar
              dataKey="value"
              fill="hsl(var(--chart-1))"
              name="Patient Value"
              radius={[0, 4, 4, 0]}
            />
            <Bar
              dataKey="normal"
              fill="hsl(var(--chart-2))"
              name="Normal Range (Avg)"
              radius={[0, 4, 4, 0]}
            />
          </BarChart>
        </ResponsiveContainer>
      </CardContent>
    </Card>
  );
}
