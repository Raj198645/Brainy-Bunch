import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { FileText, Download, Eye } from "lucide-react";

interface ReportPreviewProps {
  patientName: string;
  patientId: string;
  analysisId: string;
  date: string;
  findings: number;
  confidence: number;
  onDownload: () => void;
}

export function ReportPreview({
  patientName,
  patientId,
  analysisId,
  date,
  findings,
  confidence,
  onDownload,
}: ReportPreviewProps) {
  return (
    <Card data-testid="card-report-preview">
      <CardHeader>
        <div className="flex items-center gap-2">
          <FileText className="h-5 w-5 text-primary" />
          <CardTitle>Downloadable Report Summary</CardTitle>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
          <div>
            <p className="text-muted-foreground">Patient</p>
            <p className="font-medium">{patientName}</p>
            <p className="text-xs font-mono text-muted-foreground">{patientId}</p>
          </div>
          <div>
            <p className="text-muted-foreground">Analysis ID</p>
            <p className="font-medium font-mono">{analysisId}</p>
          </div>
          <div>
            <p className="text-muted-foreground">Date</p>
            <p className="font-medium">{date}</p>
          </div>
          <div>
            <p className="text-muted-foreground">Confidence Score</p>
            <p className="font-medium">{confidence}%</p>
          </div>
        </div>

        <div className="p-4 rounded-md bg-muted/50">
          <p className="text-sm font-medium mb-2">Report Contents:</p>
          <ul className="text-sm text-muted-foreground space-y-1">
            <li>• Patient demographic information</li>
            <li>• Complete laboratory results with status indicators</li>
            <li>• {findings} diagnostic suggestion{findings !== 1 ? 's' : ''} with confidence scores</li>
            <li>• Detailed AI reasoning and explanations</li>
            <li>• Contributing factors analysis</li>
            <li>• Medical rationale for each finding</li>
          </ul>
        </div>

        <div className="flex items-center gap-3">
          <Button onClick={onDownload} className="flex-1" data-testid="button-download-pdf">
            <Download className="h-4 w-4 mr-2" />
            Download PDF Report
          </Button>
          <Button variant="outline" onClick={() => console.log("Preview report")}>
            <Eye className="h-4 w-4 mr-2" />
            Preview
          </Button>
        </div>

        <div className="p-3 rounded-md border border-chart-4/20 bg-chart-4/5">
          <p className="text-xs text-muted-foreground">
            <strong>Disclaimer:</strong> This AI-generated report should be reviewed by a qualified 
            healthcare professional before making any medical decisions. It is intended as a 
            diagnostic aid, not a replacement for professional medical judgment.
          </p>
        </div>
      </CardContent>
    </Card>
  );
}
