import { useState } from "react";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Lightbulb, TrendingUp } from "lucide-react";

interface Factor {
  name: string;
  importance: number;
  description: string;
}

interface Explanation {
  condition: string;
  reasoning: string;
  factors: Factor[];
  references: string[];
}

interface ExplainabilityPanelProps {
  explanations: Explanation[];
}

export function ExplainabilityPanel({ explanations }: ExplainabilityPanelProps) {
  return (
    <Card data-testid="panel-explainability">
      <CardHeader>
        <div className="flex items-center gap-2">
          <Lightbulb className="h-5 w-5 text-primary" />
          <CardTitle>AI Reasoning & Explanations</CardTitle>
        </div>
      </CardHeader>
      <CardContent>
        <Accordion type="single" collapsible className="w-full">
          {explanations.map((explanation, index) => (
            <AccordionItem key={index} value={`item-${index}`}>
              <AccordionTrigger data-testid={`trigger-explanation-${index}`}>
                <span className="font-semibold">{explanation.condition}</span>
              </AccordionTrigger>
              <AccordionContent>
                <div className="space-y-4 pt-2">
                  <div>
                    <h4 className="text-sm font-medium mb-2">Medical Rationale</h4>
                    <p className="text-sm text-muted-foreground">
                      {explanation.reasoning}
                    </p>
                  </div>

                  <div>
                    <h4 className="text-sm font-medium mb-3">Contributing Factors</h4>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                      {explanation.factors.map((factor, fIndex) => (
                        <div
                          key={fIndex}
                          className="p-3 rounded-md border"
                          data-testid={`card-factor-${fIndex}`}
                        >
                          <div className="flex items-start justify-between gap-2 mb-2">
                            <span className="text-sm font-medium">{factor.name}</span>
                            <Badge variant="outline" className="text-xs">
                              {factor.importance}% importance
                            </Badge>
                          </div>
                          <p className="text-xs text-muted-foreground">
                            {factor.description}
                          </p>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div>
                    <h4 className="text-sm font-medium mb-2">Referenced Lab Values</h4>
                    <ul className="space-y-1">
                      {explanation.references.map((ref, rIndex) => (
                        <li
                          key={rIndex}
                          className="text-sm text-muted-foreground flex items-center gap-2"
                        >
                          <TrendingUp className="h-3 w-3" />
                          {ref}
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </AccordionContent>
            </AccordionItem>
          ))}
        </Accordion>
      </CardContent>
    </Card>
  );
}
