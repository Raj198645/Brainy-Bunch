import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Legend,
} from "recharts";

// todo: remove mock functionality
const mockData = [
  { month: "Jun", accuracy: 89.5, confidence: 85.2 },
  { month: "Jul", accuracy: 91.2, confidence: 87.8 },
  { month: "Aug", accuracy: 92.1, confidence: 89.3 },
  { month: "Sep", accuracy: 93.4, confidence: 91.1 },
  { month: "Oct", accuracy: 93.8, confidence: 92.5 },
  { month: "Nov", accuracy: 94.5, confidence: 93.8 },
];

export function AccuracyMetricsChart() {
  return (
    <Card data-testid="chart-accuracy-metrics">
      <CardHeader>
        <CardTitle>AI Performance Metrics</CardTitle>
      </CardHeader>
      <CardContent>
        <ResponsiveContainer width="100%" height={300}>
          <LineChart data={mockData}>
            <CartesianGrid strokeDasharray="3 3" className="stroke-border" />
            <XAxis
              dataKey="month"
              className="text-xs"
              tick={{ fill: "hsl(var(--muted-foreground))" }}
            />
            <YAxis
              domain={[80, 100]}
              className="text-xs"
              tick={{ fill: "hsl(var(--muted-foreground))" }}
              label={{
                value: "Percentage (%)",
                angle: -90,
                position: "insideLeft",
                style: { fill: "hsl(var(--muted-foreground))" },
              }}
            />
            <Tooltip
              contentStyle={{
                backgroundColor: "hsl(var(--popover))",
                border: "1px solid hsl(var(--border))",
                borderRadius: "6px",
              }}
              formatter={(value: number) => `${value}%`}
            />
            <Legend />
            <Line
              type="monotone"
              dataKey="accuracy"
              stroke="hsl(var(--chart-2))"
              strokeWidth={2}
              name="Diagnostic Accuracy"
              dot={{ fill: "hsl(var(--chart-2))", r: 4 }}
            />
            <Line
              type="monotone"
              dataKey="confidence"
              stroke="hsl(var(--chart-1))"
              strokeWidth={2}
              name="Average Confidence"
              dot={{ fill: "hsl(var(--chart-1))", r: 4 }}
            />
          </LineChart>
        </ResponsiveContainer>
      </CardContent>
    </Card>
  );
}
