import { AccuracyMetricsChart } from "../AccuracyMetricsChart";

export default function AccuracyMetricsChartExample() {
  return (
    <div className="p-6">
      <AccuracyMetricsChart />
    </div>
  );
}
