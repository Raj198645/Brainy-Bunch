import { DiagnosticCard } from "../DiagnosticCard";

export default function DiagnosticCardExample() {
  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 p-6">
      <DiagnosticCard
        condition="Type 2 Diabetes"
        confidence={87}
        severity="high"
        description="Elevated blood glucose levels suggest possible diabetes. Immediate medical consultation recommended."
        keyFactors={[
          "Fasting glucose: 126 mg/dL (elevated)",
          "HbA1c: 7.2% (above normal range)",
          "Family history of diabetes",
          "BMI indicates overweight status",
        ]}
      />
      <DiagnosticCard
        condition="Anemia"
        confidence={72}
        severity="medium"
        description="Low hemoglobin and red blood cell count indicate potential anemia. Further testing recommended."
        keyFactors={[
          "Hemoglobin: 10.5 g/dL (below normal)",
          "Low red blood cell count",
          "Reported fatigue symptoms",
        ]}
      />
    </div>
  );
}
