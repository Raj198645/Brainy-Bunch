import { StatCard } from "../StatCard";
import { Users, Activity, TrendingUp, FileText } from "lucide-react";

export default function StatCardExample() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 p-6">
      <StatCard
        title="Total Patients"
        value="1,234"
        icon={Users}
        trend="+12% from last month"
        trendUp={true}
      />
      <StatCard
        title="Analyses Today"
        value="48"
        icon={Activity}
        trend="+8% from yesterday"
        trendUp={true}
      />
      <StatCard
        title="Accuracy Rate"
        value="94.5%"
        icon={TrendingUp}
        trend="+2.1% improvement"
        trendUp={true}
      />
      <StatCard
        title="Reports Generated"
        value="892"
        icon={FileText}
        trend="+18% this week"
        trendUp={true}
      />
    </div>
  );
}
