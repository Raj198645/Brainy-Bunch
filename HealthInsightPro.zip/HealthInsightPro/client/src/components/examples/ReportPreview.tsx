import { ReportPreview } from "../ReportPreview";

export default function ReportPreviewExample() {
  return (
    <div className="p-6">
      <ReportPreview
        patientName="Sarah Johnson"
        patientId="P-45821"
        analysisId="A-2024-001"
        date="November 4, 2024"
        findings={3}
        confidence={87}
        onDownload={() => console.log("Download report")}
      />
    </div>
  );
}
