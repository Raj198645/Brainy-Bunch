import { FindingsDistributionChart } from "../FindingsDistributionChart";

export default function FindingsDistributionChartExample() {
  return (
    <div className="p-6">
      <FindingsDistributionChart />
    </div>
  );
}
