import { ExplainabilityPanel } from "../ExplainabilityPanel";

const mockExplanations = [
  {
    condition: "Type 2 Diabetes",
    reasoning:
      "The combination of elevated fasting glucose levels (126 mg/dL), high HbA1c (7.2%), and patient's BMI suggests impaired glucose metabolism consistent with Type 2 Diabetes. The pattern indicates sustained hyperglycemia over the past 2-3 months.",
    factors: [
      {
        name: "Elevated Glucose",
        importance: 45,
        description: "Fasting glucose significantly above normal threshold",
      },
      {
        name: "High HbA1c",
        importance: 35,
        description: "Indicates poor long-term glucose control",
      },
      {
        name: "BMI Factor",
        importance: 15,
        description: "Increased insulin resistance risk",
      },
      {
        name: "Family History",
        importance: 5,
        description: "Genetic predisposition present",
      },
    ],
    references: [
      "Blood Glucose: 126 mg/dL (ref: 70-100 mg/dL)",
      "HbA1c: 7.2% (ref: 4.0-5.6%)",
      "BMI: 28.5 (overweight category)",
    ],
  },
  {
    condition: "Anemia",
    reasoning:
      "Low hemoglobin levels combined with reduced red blood cell count and patient-reported fatigue symptoms indicate iron deficiency anemia. The severity suggests moderate anemia requiring medical intervention.",
    factors: [
      {
        name: "Low Hemoglobin",
        importance: 50,
        description: "Primary indicator of anemia",
      },
      {
        name: "RBC Count",
        importance: 30,
        description: "Reduced oxygen-carrying capacity",
      },
      {
        name: "Symptoms",
        importance: 20,
        description: "Clinical presentation supports diagnosis",
      },
    ],
    references: [
      "Hemoglobin: 10.5 g/dL (ref: 12.0-16.0 g/dL)",
      "RBC Count: 3.8 M/µL (ref: 4.2-5.4 M/µL)",
    ],
  },
];

export default function ExplainabilityPanelExample() {
  return (
    <div className="p-6">
      <ExplainabilityPanel explanations={mockExplanations} />
    </div>
  );
}
