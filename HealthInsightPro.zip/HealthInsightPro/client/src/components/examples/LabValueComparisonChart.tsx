import { LabValueComparisonChart } from "../LabValueComparisonChart";

const mockLabData = [
  { test: "Glucose", value: 126, normal: 85, unit: "mg/dL" },
  { test: "Hemoglobin", value: 14.2, normal: 14.0, unit: "g/dL" },
  { test: "Platelets", value: 85, normal: 275, unit: "K/µL" },
  { test: "WBC", value: 12.5, normal: 7.0, unit: "K/µL" },
  { test: "HbA1c", value: 7.2, normal: 5.0, unit: "%" },
];

export default function LabValueComparisonChartExample() {
  return (
    <div className="p-6">
      <LabValueComparisonChart data={mockLabData} />
    </div>
  );
}
