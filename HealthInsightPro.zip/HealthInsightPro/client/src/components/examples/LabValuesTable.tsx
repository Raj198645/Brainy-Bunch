import { LabValuesTable } from "../LabValuesTable";

const mockLabValues = [
  {
    test: "White Blood Cell Count",
    value: "12.5",
    unit: "K/µL",
    referenceRange: "4.0-10.0 K/µL",
    status: "abnormal" as const,
  },
  {
    test: "Hemoglobin",
    value: "14.2",
    unit: "g/dL",
    referenceRange: "12.0-16.0 g/dL",
    status: "normal" as const,
  },
  {
    test: "Platelet Count",
    value: "85",
    unit: "K/µL",
    referenceRange: "150-400 K/µL",
    status: "critical" as const,
  },
  {
    test: "Blood Glucose",
    value: "126",
    unit: "mg/dL",
    referenceRange: "70-100 mg/dL",
    status: "abnormal" as const,
  },
  {
    test: "Creatinine",
    value: "0.9",
    unit: "mg/dL",
    referenceRange: "0.6-1.2 mg/dL",
    status: "normal" as const,
  },
];

export default function LabValuesTableExample() {
  return (
    <div className="p-6">
      <LabValuesTable values={mockLabValues} />
    </div>
  );
}
