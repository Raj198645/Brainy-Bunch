import { FileUploadZone } from "../FileUploadZone";

export default function FileUploadZoneExample() {
  return (
    <div className="p-6">
      <FileUploadZone onFilesChange={(files) => console.log('Files changed:', files)} />
    </div>
  );
}
