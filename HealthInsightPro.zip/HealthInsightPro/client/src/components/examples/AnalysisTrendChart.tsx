import { AnalysisTrendChart } from "../AnalysisTrendChart";

export default function AnalysisTrendChartExample() {
  return (
    <div className="p-6">
      <AnalysisTrendChart />
    </div>
  );
}
