import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Legend,
} from "recharts";

// todo: remove mock functionality
const mockData = [
  { date: "Nov 1", analyses: 32, findings: 18 },
  { date: "Nov 2", analyses: 28, findings: 15 },
  { date: "Nov 3", analyses: 35, findings: 22 },
  { date: "Nov 4", analyses: 48, findings: 28 },
  { date: "Nov 5", analyses: 42, findings: 24 },
  { date: "Nov 6", analyses: 38, findings: 20 },
  { date: "Nov 7", analyses: 45, findings: 26 },
];

export function AnalysisTrendChart() {
  return (
    <Card data-testid="chart-analysis-trend">
      <CardHeader>
        <CardTitle>Analysis Trends (7 Days)</CardTitle>
      </CardHeader>
      <CardContent>
        <ResponsiveContainer width="100%" height={300}>
          <LineChart data={mockData}>
            <CartesianGrid strokeDasharray="3 3" className="stroke-border" />
            <XAxis
              dataKey="date"
              className="text-xs"
              tick={{ fill: "hsl(var(--muted-foreground))" }}
            />
            <YAxis
              className="text-xs"
              tick={{ fill: "hsl(var(--muted-foreground))" }}
            />
            <Tooltip
              contentStyle={{
                backgroundColor: "hsl(var(--popover))",
                border: "1px solid hsl(var(--border))",
                borderRadius: "6px",
              }}
            />
            <Legend />
            <Line
              type="monotone"
              dataKey="analyses"
              stroke="hsl(var(--chart-1))"
              strokeWidth={2}
              name="Total Analyses"
              dot={{ fill: "hsl(var(--chart-1))", r: 4 }}
            />
            <Line
              type="monotone"
              dataKey="findings"
              stroke="hsl(var(--chart-4))"
              strokeWidth={2}
              name="Abnormal Findings"
              dot={{ fill: "hsl(var(--chart-4))", r: 4 }}
            />
          </LineChart>
        </ResponsiveContainer>
      </CardContent>
    </Card>
  );
}
