import { CheckCircle, AlertTriangle, XCircle } from "lucide-react";
import { Badge } from "@/components/ui/badge";

interface LabValue {
  test: string;
  value: string;
  unit: string;
  referenceRange: string;
  status: "normal" | "abnormal" | "critical";
}

interface LabValuesTableProps {
  values: LabValue[];
}

export function LabValuesTable({ values }: LabValuesTableProps) {
  const getStatusIcon = (status: string) => {
    switch (status) {
      case "normal":
        return <CheckCircle className="h-5 w-5 text-chart-2" />;
      case "abnormal":
        return <AlertTriangle className="h-5 w-5 text-chart-4" />;
      case "critical":
        return <XCircle className="h-5 w-5 text-destructive" />;
      default:
        return null;
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "normal":
        return (
          <Badge variant="outline" className="bg-chart-2/10 text-chart-2 border-chart-2/20">
            Normal
          </Badge>
        );
      case "abnormal":
        return (
          <Badge variant="outline" className="bg-chart-4/10 text-chart-4 border-chart-4/20">
            Abnormal
          </Badge>
        );
      case "critical":
        return (
          <Badge variant="outline" className="bg-destructive/10 text-destructive border-destructive/20">
            Critical
          </Badge>
        );
      default:
        return null;
    }
  };

  return (
    <div className="rounded-lg border overflow-hidden" data-testid="table-lab-values">
      <div className="overflow-x-auto">
        <table className="w-full">
          <thead className="bg-muted/50">
            <tr>
              <th className="text-left p-4 text-sm font-semibold">Test Name</th>
              <th className="text-left p-4 text-sm font-semibold">Value</th>
              <th className="text-left p-4 text-sm font-semibold">Reference Range</th>
              <th className="text-left p-4 text-sm font-semibold">Status</th>
            </tr>
          </thead>
          <tbody>
            {values.map((value, index) => (
              <tr
                key={index}
                className="border-t hover-elevate"
                data-testid={`row-lab-value-${index}`}
              >
                <td className="p-4 text-sm">{value.test}</td>
                <td className="p-4">
                  <span className="font-mono font-medium text-lg">
                    {value.value} {value.unit}
                  </span>
                </td>
                <td className="p-4 text-sm text-muted-foreground font-mono">
                  {value.referenceRange}
                </td>
                <td className="p-4">
                  <div className="flex items-center gap-2">
                    {getStatusIcon(value.status)}
                    {getStatusBadge(value.status)}
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
