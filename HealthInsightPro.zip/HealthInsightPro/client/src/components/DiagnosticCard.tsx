import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { AlertCircle, Info } from "lucide-react";

interface DiagnosticCardProps {
  condition: string;
  confidence: number;
  severity: "low" | "medium" | "high";
  description: string;
  keyFactors: string[];
}

export function DiagnosticCard({
  condition,
  confidence,
  severity,
  description,
  keyFactors,
}: DiagnosticCardProps) {
  const getSeverityBadge = () => {
    switch (severity) {
      case "high":
        return (
          <Badge variant="outline" className="bg-destructive/10 text-destructive border-destructive/20">
            High Risk
          </Badge>
        );
      case "medium":
        return (
          <Badge variant="outline" className="bg-chart-4/10 text-chart-4 border-chart-4/20">
            Medium Risk
          </Badge>
        );
      case "low":
        return (
          <Badge variant="outline" className="bg-chart-1/10 text-chart-1 border-chart-1/20">
            Low Risk
          </Badge>
        );
    }
  };

  return (
    <Card data-testid={`card-diagnostic-${condition.toLowerCase().replace(/\s+/g, '-')}`}>
      <CardHeader className="gap-2">
        <div className="flex items-start justify-between gap-4 flex-wrap">
          <CardTitle className="text-xl">{condition}</CardTitle>
          {getSeverityBadge()}
        </div>
        <div className="space-y-2">
          <div className="flex items-center justify-between gap-2">
            <span className="text-sm text-muted-foreground">Confidence</span>
            <span className="text-sm font-mono font-semibold">{confidence}%</span>
          </div>
          <Progress value={confidence} className="h-2" />
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        <p className="text-sm text-muted-foreground">{description}</p>
        
        <div className="space-y-2">
          <div className="flex items-center gap-2">
            <AlertCircle className="h-4 w-4 text-muted-foreground" />
            <span className="text-sm font-medium">Key Contributing Factors</span>
          </div>
          <ul className="space-y-1 ml-6">
            {keyFactors.map((factor, index) => (
              <li
                key={index}
                className="text-sm text-muted-foreground list-disc"
                data-testid={`text-factor-${index}`}
              >
                {factor}
              </li>
            ))}
          </ul>
        </div>
      </CardContent>
    </Card>
  );
}
